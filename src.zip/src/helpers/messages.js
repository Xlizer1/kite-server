module.exports = {
    userExists: "User already exists!",
    userDoesntExist: "User does not exist!",
}