const { executeQuery } = require("../../helpers/common");
const { CustomError } = require("../../middleware/errorHandler");

const getRoles = async (user, callBack) => {
  let sql = `
    SELECT
      *
    FROM
      roles
  `;
  
  executeQuery(sql, "registerUser", (result) => {
    if (Array.isArray(result) && !result[0]) {
      return callBack(new CustomError(result[1], 400));
    }

    if (Array.isArray(result)) {
      return callBack(result);
    }

    return callBack(new CustomError("An unknown error occurred during registration.", 500));
  });
};

const createRoles = async (name, callBack) => {
  let sql = `
    INSERT INTO
      roles
    SET
      name = "${name}"
  `;
  
  executeQuery(sql, "registerUser", (result) => {
    if (Array.isArray(result) && !result[0]) {
      return callBack(new CustomError(result[1], 400));
    }

    if (Array.isArray(result)) {
      return callBack(true);
    }

    return callBack(new CustomError("An unknown error occurred during registration.", 500));
  });
};

const updateRoles = async (id, name) => {
  return new Promise((resolve, reject) => {
    let sql = `
      UPDATE
        roles
      SET
        name = "${name}"
      WHERE
        id = ${id}
    `;
    executeQuery(sql, "updateRoles", result => {
      if (Array.isArray(result) &&!result[0]) {
        return reject(new CustomError(result[1], 400));
      }
      
      if (result && result.affectedRows > 0) {
        return resolve(true);
      }
      
      return reject(new CustomError("An unknown error occurred during roles update.", 500));
    })
  })
}

const updateUserPermissions = async (id, roles) => {
  return new Promise((resolve, reject) => {
    executeQuery(`DELETE FROM permissions WHERE user_id = ${id}`, "deleting user roles", (result) => result);
    let roleSql = `
      INSERT INTO
        permissions (
          user_id,
          role_id
        )
      VALUES
        ${roles.map((role) => `(${id}, ${role})`).join(",")}
    `;
    executeQuery(roleSql, "inserting user roles", result => {
      if (Array.isArray(result) &&!result[0]) {
        return reject(new CustomError(result[1], 400));
      }
      
      if (result && result.affectedRows > 0) {
        return resolve(true);
      }
      
      return reject(new CustomError("An unknown error occurred during roles update.", 500));
    })
  })
}

const deleteRoles = async (id) => {
  return new Promise((resolve, reject) => {
    let sql = `
      DELETE FROM
        roles
      WHERE
        id = ${id}
    `;
    executeQuery(sql, "deleteRoles", result => {
      if (Array.isArray(result) &&!result[0]) {
        return reject(new CustomError(result[1], 400));
      }
      
      if (result && result.affectedRows > 0) {
        return resolve(true);
      }
      
      return reject(new CustomError("An unknown error occurred during roles deletion.", 500));
    })
  })
}

module.exports = {
  getRolesModel: getRoles,
  createRolesModel: createRoles,
  updateRolesModel: updateRoles,
  updateUserPermissionsModel: updateUserPermissions,
  deleteRolesModel: deleteRoles,
};
